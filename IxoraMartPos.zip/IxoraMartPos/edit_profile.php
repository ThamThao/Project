<?php

include_once('admin_dashboard.php');

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "DATABASE";

$connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$connection) {
    die("ERROR: Connection Failed! Could not connect to the database!</body></html>");
}

error_reporting(1);

if (!mysqli_select_db($connection, $db_name)) {
    die("Could not open Company database.</body></html>");
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="confirmpopup.css">
    <title>Edit Staff</title>
    <style>
        body {
            height: 1000px;
        }


        .label-bold {
            color: #000000;
            font-family: 'Open Sans', sans-serif;
            font-weight: bolder;
            font-size: 16px;
            margin: 20px;

        }

        .label-bold th,
        td {
            border-bottom: 0;
        }

        .textField {
            height: 30px;
            background: #FFFFFF;
            border: 1px solid #C5C4C4;
            border-radius: 8px;
            font-family: 'Roboto', sans-serif;
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            color: black;
            padding: 5px;
            margin: 20px;

        }

        .yellowBtn {
            background-color: #F9EAE1;
            width: 80px;
            height: 30px;
            box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.25);
            border-radius: 8px;
            color: black;
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: bolder;
            font-size: 12px;
            text-decoration: none;
            border: #F9EAE1;
        }
    </style>
</head>

<body>
    <?php
    $staffid = $_GET['staff_id'];
    $viewSql = "SELECT * FROM staff where staff_id =$staffid";
    $result = mysqli_query($connection, $viewSql);

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $name = $row['staff_name'];
            $birthdate = $row['staff_birthdate'];
            $ic = $row['staff_ic'];
            $gender = $row['staff_sex'];
            $address = $row['staff_address'];
            $m_status = $row['staff_m_status'];
            $email = $row['staff_email'];
            $contact = $row['staff_contact'];
            $hire_date = $row['hire_date'];
            $position = $row['position'];
            $bankname = $row['bank_name'];
            $bankacc = $row['bank_acc'];
            $password = $row['password'];
        }
    }
    ?>

    <div class="container">
        <form action="" method="post">
            <table style="position: absolute; top: 96px; left: 305px;">
                <tr>
                    <td style="font-family: 'Open Sans', sans-serif; font-weight: bolder; font-size: 22px;">Edit Staff</td>
                    <td></td>
                    <td style="height: 30px; background: #FFFFFF; border: 1px solid #C5C4C4; border-radius: 8px;"><?php echo $staffid; ?></td>
                </tr>
            </table>

            <table style="position: absolute; left: 500px; top: 125px;">
                <tbody>

                    <tr>
                        <td class="label-bold">Name</td>
                        <td><input class="textField" type="text" name="name" value="<?php echo $name; ?>" pattern="[a-zA-Z_][a-zA-Z_ ]*[a-zA-Z_]$" title="The name of the staff can only contain string!" required></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="label-bold">Date of Birth</td>
                        <td><input class="textField" type="date" name="birthdate" value="<?php echo $birthdate; ?>" required></td>
                        <td></td>
                        <td class="label-bold">No. IC</td>
                        <td><input class="textField" type="text" name="ic" value="<?php echo $ic; ?>" pattern="\d{6}-\d{2}-\d{4}$" title="You have entered an invalid IC number!" required></td>
                    </tr>
                    <tr>
                        <td class="label-bold">Gender</td>
                        <td>
                            <select name="gender" class="textField">
                                <option value="M" <?php if ($gender == "M") echo "selected"; ?>>Male</option>
                                <option value="F" <?php if ($gender == "F") echo "selected"; ?>>Female</option>
                            </select>
                        </td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="label-bold">Address</td>
                        <td colspan=4><input class="textField" type="text" name="address" value="<?php echo $address; ?>" size="50" required></td>
                    </tr>

                    <tr>
                        <td class="label-bold">Marital Status</td>
                        <td>
                            <select name="m_status" class="textField">
                                <option value="Married" <?php if ($m_status == "Married") echo "selected"; ?>>Married</option>
                                <option value="Single" <?php if ($m_status == "Single") echo "selected"; ?>>Single</option>
                            </select>
                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td class="label-bold">Email</td>
                        <td><input class="textField" type="email" name="email" value="<?php echo $email; ?>" title="You have entered an invalid email address!" required></td>
                        <td></td>
                        <td class="label-bold">Contact</td>
                        <td><input class="textField" type="text" name="contact" value="<?php echo $contact; ?>" pattern="\d*$" title="You have entered an invalid contact number!" required></td>
                    </tr>

                    <tr>
                        <td class="label-bold">Hire Date</td>
                        <td><input class="textField" type="date" name="hire_date" value="<?php echo $hire_date; ?>" required></td>
                        <td></td>
                        <td class="label-bold">Position</td>
                        <td>
                            <select name="position" class="textField" required>
                                <option value="Sales Assistant" <?php if ($position == "Sales Assistant") echo "selected"; ?>>Sales Assistant</option>
                                <option value="Cashier" <?php if ($position == "Cashier") echo "selected"; ?>>Cashier</option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <td class="label-bold">Bank Name</td>
                        <td><input class="textField" type="text" name="bankname" value="<?php echo $bankname; ?>" pattern="[a-zA-Z_][a-zA-Z_ ]*[a-zA-Z_]$" title="The name of the bank can only contain string!" required></td>
                        <td></td>
                        <td class="label-bold">Account No.</td>
                        <td><input class="textField" type="text" name="bankacc" value="<?php echo $bankacc; ?>" pattern="\d*$" title="Account No. can only contain number!" required></td>
                    </tr>

                    <tr>
                        <td class="label-bold">Password</td>
                        <td><input class="textField" type="text" name="password" value="<?php echo $password; ?>" required></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td><input class="yellowBtn" type="submit" name="btnEdit" value="Edit"></td>
                        <td><a href="staff_list.php"><input class="yellowBtn" type="button" name="btnCancel" value="Cancel"></a></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
        </form>
    </div>
    <div id="confirmBox" class="confirmBox"></div>

    <div id="popup" class="popup">
        <div class="message">Are you sure?</div>
        <div class="buttons">
            <button id="confirm-button">Confirm</button>
            <button id="cancel-button">Cancel</button>
        </div>
    </div>
    <script src="confirmpopup.js"></script>
</body>

</html>

<?php
if (isset($_POST['btnEdit'])) {
    // extract($_POST);

    $name = $_POST['name'];
    $birthdate = $_POST['birthdate'];
    $ic = $_POST['ic'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $m_status = $_POST['m_status'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $hire_date = $_POST['hire_date'];
    $position = $_POST['position'];
    $bankname = $_POST['bankname'];
    $bankacc = $_POST['bankacc'];
    $password = $_POST['password'];


    $update = "UPDATE staff SET staff_name='$name', staff_birthdate='$birthdate', staff_ic='$ic', staff_sex='$gender', staff_address='$address', staff_m_status='$m_status', staff_email='$email', staff_contact='$contact', hire_date='$hire_date', position='$position', bank_name='$bankname', bank_acc='$bankacc', password='$password' WHERE staff_id='$staffid'";
    if (mysqli_query($connection, $update)) {
        echo '<script>window.location.href = "staff_list.php";</script>';
        exit();
    } else {
        echo '<script>alert("Data failed, try again.")</script>';
    }
}
?>