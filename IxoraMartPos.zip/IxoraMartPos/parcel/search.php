<style>
	#resultTable {
		border-collapse: separate;
		background-color: #FFFFFF;
		border-spacing: 0;
		width: 85%;
		color: #666666;
		text-shadow: 0 1px 0 #FFFFFF;
		border: 1px solid #CCCCCC;
		box-shadow: 0;
		margin: 0 auto;
		font-family: arial;
		position: absolute;
		left: 240px;
		top: 85px;
	}

	table thead tr th {
		background: none repeat scroll 0 0 #EEEEEE;
		color: #222222;
		padding: 10px 14px;
		text-align: left;
		border-top: 0 none;
		font-size: 18px;
	}

	.parcel {
		background-color: #F5F595;
		font-size: 16px;
		text-align: left;
		padding: 10px 14px;
		border-top: 1px solid #DDDDDD;
		font-family: 'Roboto', sans-serif;

	}
</style>
<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Cashier' || $_SESSION['position'] === 'Sales Assistant') {
	header("Location: ../login.php");
	exit;
}
?>
<?php
include('connectParcel.php');
?>

<table cellspacing="0" cellpadding="2" id="resultTable">
	<thead>
		<tr>
			<th width="15%"> Date In</th>
			<th width="15%"> Date Out</th>
			<th width="15%"> Parcel ID</th>
			<th width="15%"> Customer Name</th>
			<th width="15%"> Block No.</th>
			<th width="10%"> Status </th>
			<th width="15%"> Action </th>
		</tr>
	</thead>
	<tbody>
		<?php
		$search = $_POST['search'];
		$sql = "select * from ParcelRecord where customer_name like '%$search%'";
		$result = $db->query($sql);
		if ($result->rowCount() > 0) {
			while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
		?>
				<tr class="parcel">
					<td><?php echo $row['date_in']; ?></td>
					<td><?php echo $row['date_out']; ?></td>
					<td><?php echo $row['parcel_ID']; ?></td>
					<td><?php echo $row['customer_name']; ?></td>
					<td><?php echo $row['block_no']; ?></td>
					<td><?php echo $row['status']; ?></td>
					<td><a href="Parcel_Interface_edit.php?id=<?php echo $row['id']; ?>"> <img src="../images/tteditbutton.png" height="15px" width="15px"> </a> | <a href="#" id="<?php echo $row['id']; ?>" class="delbutton" title="Click To Delete"><img src="../images/ttdeletebutton.png" height="15px" width="15px"></a></td>
					<td>
				</tr>
			<?php
			}
			?>
		<?php
		} else {
			echo "Sorry, no records found";
		}
		?>
		<script src="../jquery-1.3.2.js"></script>
		<script type="text/javascript">
			$(function() {


				$(".delbutton").click(function() {

					//Save the link in a variable called element
					var element = $(this);

					//Find the id of the link that was clicked
					var del_id = element.attr("id");

					//Built a url to send
					var info = 'id=' + del_id;
					if (confirm("Are you sure to delete this record?")) {

						$.ajax({
							type: "GET",
							url: "delete.php",
							data: info,
							success: function() {

							}
						});
						$(this).parents(".parcel").animate({
								backgroundColor: "#fbc7c7"
							}, "fast")
							.animate({
								opacity: "hide"
							}, "slow");

					}

					return false;

				});

			});
		</script>