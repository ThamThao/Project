<style>
	body {
		background: linear-gradient(to bottom, #FFFFFF 0%, #F6F6F6 100%) repeat scroll 0 0 rgba(0, 0, 0, 0);
		;
	}

	#resultTable {
		border-collapse: separate;
		background-color: #FFFFFF;
		border-spacing: 0;
		width: 84.7%;
		color: #666666;
		text-shadow: 0 1px 0 #FFFFFF;
		border: 1px solid #CCCCCC;
		box-shadow: 0;
		font-family: arial;
		position: relative;
		margin-left: 233px;
		top: 30px;
	}

	table thead tr th {
		background: none repeat scroll 0 0 #EEEEEE;
		color: #222222;
		padding: 10px 14px;
		text-align: left;
		border-top: 0 none;
		font-size: 18px;
	}

	.parcel {
		background-color: #F5F595;
		font-size: 16px;
		text-align: left;
		padding: 10px 14px;
		border-top: 1px solid #DDDDDD;
		font-family: 'Roboto', sans-serif;

	}

	#log {
		width: 85%;
		text-align: right;
		margin: 20px auto;
		font-family: arial;
	}

	#log a {
		color: #FFFFFF;
		text-decoration: none;
		font-family: arial;
	}

	#formdesign {
		background: linear-gradient(to bottom, #FFFFFF 0%, #F6F6F6 100%) repeat scroll 0 0 rgba(0, 0, 0, 0);
		border: 1px solid #D5D5D5;
		padding: 12px;
		position: relative;
		top: 32px;
		margin-left: 233px;
		width: 83%;
		clear: both;
		height: 100px;
	}

	#add {
		float: right;
		width: 8.5%;
		display: block;
		height: 15px;
		padding: 9px 9px 9px 9px;
		border: 1px solid #DADADA;
	}

	a#add {
		text-decoration: none;
		color: black;
		font-size: 15px;
		text-align: center;
		font-family: 'Roboto', sans-serif;
		font-weight: bold;
	}

	#searchform {
		float: right;
		width: 8.5%;
		display: block;
		height: 14px;
		padding: 9px 9px 9px 9px;
		border: 1px solid #DADADA;
	}

	a#searchform {
		text-decoration: none;
		color: black;
		font-size: 15px;
		text-align: center;
		font-family: 'Roboto', sans-serif;
		font-weight: bold;
	}
</style>

<div id="log">
	<a href="../index.php">Logout</a>
</div>
<div id="formdesign">
	<h2>Parcel List</h2>
	<a href="Parcel_Interface_add.php" id="add">Add Parcel</a>
	<a href="Parcel_Interface_search.php" id="searchform"><img src="../images/searchtticon.png" height="13px" width="13px"> Search</a>

</div>
<table cellspacing="0" cellpadding="2" id="resultTable">
	<thead>
		<tr>
			<th width="5%"> Date In</th>
			<th width="7%"> Date Out</th>
			<th width="10%"> Parcel ID</th>
			<th width="13%"> Customer Name</th>
			<th width="7%"> Block No.</th>
			<th width="7%"> Status </th>
			<th width="10%"> Action </th>
		</tr>
	</thead>
	<tbody>
		<?php
		include('connectParcel.php');
		$result = $db->prepare("SELECT * FROM ParcelRecord ORDER BY id DESC"); // ParcelRecord is name of table in SQL
		$result->execute();
		for ($i = 0; $row = $result->fetch(); $i++) {
		?>
			<tr class="parcel">
				<td><?php echo $row['date_in']; ?></td>
				<td><?php echo $row['date_out']; ?></td>
				<td><?php echo $row['parcel_ID']; ?></td>
				<td><?php echo $row['customer_name']; ?></td>
				<td><?php echo $row['block_no']; ?></td>
				<td><?php echo $row['status']; ?></td>
				<td><a href="Parcel_Interface_edit.php?id=<?php echo $row['id']; ?>" class="edit"><img src="../images/tteditbutton.png" height="15px" width="15px"></a> | <a href="#" id="<?php echo $row['id']; ?>" class="delbutton" title="Click To Delete"><img src="../images/ttdeletebutton.png" height="15px" width="15px"></a></td>
			</tr>
		<?php
		}
		?>
	</tbody>
</table>
<script src="../jquery-1.3.2.js"></script>
<script type="text/javascript">
	$(function() {


		$(".delbutton").click(function() {

			//Save the link in a variable called element
			var element = $(this);

			//Find the id of the link that was clicked
			var del_id = element.attr("id");

			//Built a url to send
			var info = 'id=' + del_id;
			showPopup().then(function(result) {
				if (result) {
					$.ajax({
						type: "GET",
						url: "delete.php",
						data: info,
						success: function() {
							element.parents(".parcel")
								.animate({
									backgroundColor: "#fbc7c7"
								}, "fast")
								.animate({
									opacity: "hide"
								}, "slow");
						}
					});
				}
			});

			return false;

		});

	});
</script>