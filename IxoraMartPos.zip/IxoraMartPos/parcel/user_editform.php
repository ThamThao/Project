<style>
#editform { 
    background-color: #dde6ed;
    
	position:absolute;
    padding-left: 5px;
    padding-top:5px ;
    padding-right: 15px;
    padding-left: 5px;
	left: 550px;
    top:200px;
    border-radius: 15px;
    box-shadow: 4px 4px gray;
    font-family: 'Roboto', sans-serif;
    font-size: 27px;
}
</style>
<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Manager') {
	header("Location: ../login.php");
	exit;
}
?>

<?php
	include('connectParcel.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM ParcelRecord WHERE id= :userid");
	$result->bindParam(':userid', $id);//bind parameter
	$result->execute();
	for($i=0; $rows = $result->fetch(); $i++){
?>
<table cellspacing="0" cellpadding="2" id="editform">
<form action="user_edit.php" method="POST">
	<input type="hidden" name="memids" value="<?php echo $id; ?>" />
    <tr>
		<td>Date In</td>
		<td><input type="text" name="date_in" value="<?php echo $rows['date_in']; ?>" style="font-size:16pt;"/></td>
	</tr>
    <tr>
		<td>Date Out</td>
		<td><input type="text" name="date_out" value="<?php echo $rows['date_out']; ?>" style="font-size:16pt;"/></td>
	</tr>
    <tr>
		<td>Parcel ID</td>
		<td><input type="text" name="parcel_ID" value="<?php echo $rows['parcel_ID']; ?>" style="font-size:16pt;"/></td>
	</tr>
    <tr>
		<td>Recipient Name</td>
		<td><input type="text" name="customer_name" value="<?php echo $rows['customer_name']; ?>" style="font-size:16pt;" /></td>
	</tr>
    <tr>
		<td>Block No.</td>
		<td><input type="text" name="block_no" value="<?php echo $rows['block_no']; ?>" style="font-size:16pt;"/></td>
	</tr>
    <tr>
		<td>Status</td>
		<td><input type="radio" name="status" value="Completed" checked/>Completed</td>
        <td><input type="radio" name="status" value="Pending" />Pending</td>
	</tr>
    <tr>
        <td><input type="submit" value="Save" style="font-size:16pt;"></td>
    </tr>
</form>
</table>
<?php
	}
?>


