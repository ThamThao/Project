<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Manager') {
	header("Location: ../login.php");
	exit;
}
?>
<?php

include('connectParcel.php');	

$date_in = $_POST['date_in'];
$date_out = $_POST['date_out'];
$parcel_ID = $_POST['parcel_ID'];
$customer_name = $_POST['customer_name'];
$block_no = $_POST['block_no'];
$status = $_POST['status'];

// query
$sql = "INSERT INTO ParcelRecord (date_in,date_out,parcel_ID,customer_name,block_no,status) VALUES (:sas,:asas,:asafs,:offff,:statttt,:dot)";
$q = $db->prepare($sql);
$q->execute(array(':sas'=>$date_in,':asas'=>$date_out,':asafs'=>$parcel_ID,':offff'=>$customer_name,':statttt'=>$block_no,':dot'=>$status));
header("location: user_Parcel_Interface.php");
?>