<?php

// configuration
include('connectParcel.php');

// new data
$date_in = $_POST['date_in'];
$date_out = $_POST['date_out'];
$parcel_ID = $_POST['parcel_ID'];
$customer_name = $_POST['customer_name'];
$block_no = $_POST['block_no'];
$status = $_POST['status'];
$id = $_POST['memids'];

// query
$sql = "UPDATE ParcelRecord
        SET date_in=?, date_out=?, parcel_ID=?, customer_name=?, block_no=?, status=?
		WHERE id=?";
$q = $db->prepare($sql);
$q->execute(array($date_in,$date_out,$parcel_ID,$customer_name,$block_no,$status,$id));
header("location: user_Parcel_Interface.php");

?>