<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id'])) {
    header("Location: login.php");
    exit;
}
?>
<?php

    if (!($connection = mysqli_connect("localhost","root","","DATABASE")))
    die("Could not connect to database </body><html>");

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $qty = $_POST['qty'];
        $unitPrice = $_POST['unitPrice'];
        $subtotal = $_POST['subtotal'];
    
        // Process the data here
        $query = "INSERT INTO temp_for_receipt VALUES ($id, '$name', $qty, $unitPrice, $subtotal)";
        if(!($result=mysqli_query($connection,$query)))
            {
                print("<p>Could not execute query!</p>");
                die(mysqli_error($connection)."</body></html>");
            }
        
        if (mysqli_affected_rows($connection) > 0) 
        {
            //output result
            echo "OK";
        }
        
        mysqli_close($connection);

    }

?>