<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Staff List</title>
    <link rel="stylesheet" href="admin_dashboard_design.css">
    <link rel="stylesheet" href="confirmpopup.css">
    <script src="staff_list.js"></script>

    <style>
        .table-striped {
            position: fixed;
            top: 260px;
            left: 28px;
            border: solid;
            border-color: grey;
            width: 100%;
            border-collapse: collapse;
        }

        .table-striped th {
            text-align: left;
            padding-left: 10px;
            padding-top: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #C5C4C4;
            text-align: left;
            background-color: dimgrey;
            color: white;
            padding-left: 10px;
        }

        .table-striped tr:nth-child(odd) {
            background-color: #d4d4d4;
            /* Apply background color to odd rows */
        }

        .yellowBtn {
            background-color: #F9EAE1;
            width: 70px;
            height: 20px;
            box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.25);
            border-radius: 8px;
            color: black;
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: bolder;
            font-size: 12px;
            padding: 10px;
            text-decoration: none;
        }

        .yellowBtn a:visited,
        a:hover {
            text-decoration: none;
        }


        .export a:visited,
        a:hover {
            text-decoration: none;
        }

        .searchBar {
            position: absolute;
            top: 213px;
            right: 315px;
            width: 190px;
            height: 38px;
            color: darkgrey;
            box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.25);
            border: #FFFFFF;
            border-radius: 8px;
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: bolder;
            font-size: 15px;
        }
    </style>
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script>
        function displayDateTime() {
            var currentDateTime = new Date();
            var dateTimeString = currentDateTime.toLocaleString();

            document.getElementById("dateTimeOutput").textContent = dateTimeString;
        }

        window.onload = function() {
            displayDateTime();
            setInterval(displayDateTime, 1000);
        };

        function confirmLogout() {
            showPopup().then(function(result) {
                if (result) {
                    window.location.href = "logout.php";
                }
            });
        }
    </script>
</head>

<body>
    <?php
    session_start();

    // Check if user is logged in and the role
    if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Cashier' || $_SESSION['position'] === 'Sales Assistant') {
        header("Location: login.php");
        exit;
    }
    ?>
    <?php
    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "";
    $db_name = "DATABASE";

    $connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if (!$connection) {
        die("ERROR: Connection Failed! Could not connect to the database!</body></html>");
    }

    error_reporting(1);
    ?>

    <section style="height:2000px">
        <div class="content">
            <h2 style="position: absolute; top: 220px; left: 305px; font-family: 'Open Sans', sans-serif; font-weight: bolder; font-size: 22px;">Staff List</h2>
            <hr />
            <form action="staff_list.php" method="get">
                <input class="searchBar" type="text" name="search" placeholder="Search staff ... "><br />
                <input style="visibility:hidden;" type="submit" value="Search">
            </form>
            <br />
            <br />
            <div class="staff-list">
                <table class="table table-striped table-hover" style="position: absolute; width:78%; left:20%;">
                    <tr>
                        <th>No.</th>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Position</th>
                        <th>Hire Date</th>
                        <th>Action</th>
                    </tr>
                    <?php
                    $no = 1; // Initialize the variable
                    if (isset($_GET['search'])) {
                        $raw_results = $_GET['search'];
                        $search_results = mysqli_query($connection, "SELECT * FROM staff WHERE position LIKE '%$raw_results%' OR staff_id LIKE '%$raw_results%' ORDER BY staff_id ASC");
                    } else {
                        $search_results = mysqli_query($connection, "SELECT * FROM staff ORDER BY staff_id ASC");
                    }
                    if (mysqli_num_rows($search_results) == 0) {
                        echo '<tr><td colspan="8">ERROR: No Record Found.</td></tr>';
                    } else {
                        while ($results = mysqli_fetch_assoc($search_results)) {
                            echo '<tr>';
                            echo '<td>' . $no . '</td>';
                            echo '<td>' . $results['staff_id'] . '</td>';
                            echo '<td>' . $results['staff_name'] . '</td>';
                            echo '<td>' . $results['staff_contact'] . '</td>';
                            echo '<td>' . $results['position'] . '</td>';
                            echo '<td>' . $results['hire_date'] . '</td>';
                            echo '<td>
                                        <a href="edit_profile.php?staff_id=' . $results['staff_id'] . '" title="Edit Profile" class="btn btn-primary btn-sm"><img src="images/tteditbutton.png" height="15px" width="15px"></a>
                                        <a href="#' . $results['staff_id'] . '" title="Delete Record" onclick="deleteRecord(' . $results['staff_id'] . ', this)" class="btn btn-danger btn-sm"><img src="images/ttdeletebutton.png" height="15px" width="15px"></a>
                                    </td>';
                            echo '</tr>';

                            $no++; // Increment the variable
                        }
                    }
                    ?>
                </table>
                <div style="position: absolute; top: 220px; right:180px;">
                    <a class="yellowBtn" href="add_profile.php"><img src="add_staff.svg" alt="CSV" width="17" height="17">&nbsp;Add New Staff</a>
                </div>
                <div style="position: absolute; top: 220px; right:30px;">
                    <a class="yellowBtn" href="export.php"><img src="csv.svg" alt="CSV" width="17" height="17">&nbsp;Export All to CSV</a>
                </div>
            </div>
    </section>
    <div class="sidebar">
        <div class="navbar"></div>
        <div class="logo">
            <img src="pics/ixoralogo.png" alt="Logo">
        </div>

        <div class="navProfile">
            <img src="pics/manager.png" alt="Profile Picture">
        </div>
        <div id="dateTimeOutput"></div>


        <div class="sidebar"></div>
        <div class="sideProfile">
            <img src="pics/manager.png" alt="Profile Picture">
        </div>
        <h2 class="accName">Manager</h2>
        <h3 class="position">Admin</h3>

        <table class="dashboardTable">
            <tr>
                <th class="menuIcon">
                    <img src="pics/home.svg" alt="Home">
                </th>
                <td class="sideMenu"><a href="PurchaseDetails.php">Home</td>
            </tr>

            <tr>
                <th class="menuIcon">
                    <img src="pics/sales.svg" alt="Sales">
                </th>
                <td class="sideMenu"><a href="SalesRecord.php">Sales</td>
            </tr>

            <tr>
                <th class="menuIcon">
                    <img src="pics/inventory.svg" alt="Inventory">
                </th>
                <td class="sideMenu"><a href="inventory/Inventory_Interface.php">Inventory</td>

            </tr>

            <tr>
                <th class="menuIcon">
                    <img src="pics/parcel.svg" alt="Parcel">
                </th>
                <td class="sideMenu"><a href="parcel/Parcel_Interface.php">Parcel</td>
            </tr>

            <tr>
                <th class="menuIcon">
                    <img src="pics/staff.svg" alt="Staff">
                </th>
                <td class="sideMenu"><a href="staff_list.php">Staff</td>
            </tr>
        </table>

        <div class="logout">
            <a href="#" onclick="confirmLogout()"><img src="pics/logout.svg" alt="Logout"></a>
        </div>
    </div>
    <div id="confirmBox" class="confirmBox"></div>

    <div id="popup" class="popup">
        <div class="message">Are you sure?</div>
        <div class="buttons">
            <button id="confirm-button">Confirm</button>
            <button id="cancel-button">Cancel</button>
        </div>
    </div>
    <script src="confirmpopup.js"></script>
</body>

</html>