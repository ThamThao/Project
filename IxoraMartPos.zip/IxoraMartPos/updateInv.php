<?php
    session_start();

    // Check if user is logged in and the role
    if (!isset($_SESSION['staff_id'])) {
        header("Location: login.php");
        exit;
    }
    ?>
<?php

    if (!($connection = mysqli_connect("localhost","root","","DATABASE")))
        die("Could not connect to database </body><html>");
    if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
        // Process the data here
        $pType = $_POST['pType'];
        $total = $_POST['total'];
        $query = "SELECT * FROM temp_for_receipt";
        if(!($result=mysqli_query($connection,$query)))
            {
                print("<p>Could not execute query!</p>");
                die(mysqli_error($connection)."</body></html>");
            }
        while ($row = mysqli_fetch_row($result))
            {
                $itemNo = $row[0];
                $qty = $row[2];
                $chsQuery = "SELECT * FROM inventory WHERE id = " . $itemNo;
                if(!($result_2=mysqli_query($connection,$chsQuery)))
                {
                    print("<p>Could not execute query!</p>");
                    die(mysqli_error($connection)."</body></html>");
                }
                $row_2 = mysqli_fetch_row($result_2);
                $newQty = floatval($row_2[6]) - floatval($qty);

                $updateQuery = "UPDATE inventory SET stock = $newQty where id = $itemNo";
                if(!($result_3=mysqli_query($connection,$updateQuery)))
                {
                    print("<p>Could not execute query!</p>");
                    die(mysqli_error($connection)."</body></html>");
                }
            }    
        
        $dltQuery = "DELETE FROM temp_for_receipt";
        if(!($result_4=mysqli_query($connection,$dltQuery)))
        {
            print("<p>Could not execute query!</p>");
            die(mysqli_error($connection)."</body></html>");
        }

        if (mysqli_affected_rows($connection) < 0) 
        {
            //output result
            echo "<script>";
            echo "alert('Unexpected error occured. Please Try Again')";
            echo "window.location.href = 'PurchaseDetails.php'";
            echo "</script>";
        } 
        date_default_timezone_set("Asia/Kuala_Lumpur");   
        $currentDate = date("Y-m-d");
        $updataInv = "INSERT INTO salesrecord values('','$pType', '$currentDate', $total)";
        if(!($result_5=mysqli_query($connection,$updataInv)))
            {
                print("<p>Could not execute query!</p>");
                die(mysqli_error($connection)."</body></html>");
            }

        mysqli_close($connection);

    }
?>
