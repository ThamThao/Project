<!DOCTYPE html>

<html>

<head>
    <title>Receipt </title>

    <link rel="stylesheet" href="receipt.css">
    <link rel="stylesheet" href="confirmpopup.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <?php
    date_default_timezone_set("Asia/Kuala_Lumpur");
    $date = date('d/m/y h:i:s');
    ?>

    <link rel="stylesheet" href="admin_dashboard_design.css">
    <script>
        function displayDateTime() {
            var currentDateTime = new Date();
            var dateTimeString = currentDateTime.toLocaleString();

            document.getElementById("dateTimeOutput").textContent = dateTimeString;
        }

        window.onload = function() {
            displayDateTime();
            setInterval(displayDateTime, 1000);
        };

        function confirmLogout() {
            showPopup().then(function(result) {
                if (result) {
                    window.location.href = "logout.php";
                }
            });
        }


        document.getElementById("directButton").addEventListener("click", function() {
            window.location.href = "PurchaseDetails.php";
        });
    </script>
</head>




<body>
    <?php
    session_start();

    // Check if user is logged in and the role
    if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Cashier' || $_SESSION['position'] === 'Sales Assistant') {
        header("Location: login.php");
        exit;
    }
    ?>
    <div class="container">
        <div class="receiptBox">

            <div class="sidebar">
                <div class="navbar"></div>
                <div class="logo">
                    <img src="pics/ixoralogo.png" alt="Logo">
                </div>

                <div class="navProfile">
                    <img src="pics/manager.png" alt="Profile Picture">
                </div>
                <div id="dateTimeOutput"></div>


                <div class="sidebar"></div>
                <div class="sideProfile">
                    <img src="pics/manager.png" alt="Profile Picture">
                </div>
                <h2 class="accName">Manager</h2>
                <h3 class="position">Admin</h3>

                <table class="dashboardTable">
                    <tr>
                        <th class="menuIcon">
                            <img src="pics/home.svg" alt="Home">
                        </th>
                        <td class="sideMenu"><a href="PurchaseDetails.php">Home</td>
                    </tr>

                    <tr>
                        <th class="menuIcon">
                            <img src="pics/sales.svg" alt="Sales">
                        </th>
                        <td class="sideMenu"><a href="SalesRecord.php">Sales</td>
                    </tr>

                    <tr>
                        <th class="menuIcon">
                            <img src="pics/inventory.svg" alt="Inventory">
                        </th>
                        <td class="sideMenu"><a href="inventory/Inventory_Interface.php">Inventory</td>

                    </tr>

                    <tr>
                        <th class="menuIcon">
                            <img src="pics/parcel.svg" alt="Parcel">
                        </th>
                        <td class="sideMenu"><a href="parcel/Parcel_Interface.php">Parcel</td>
                    </tr>

                    <tr>
                        <th class="menuIcon">
                            <img src="pics/staff.svg" alt="Staff">
                        </th>
                        <td class="sideMenu"><a href="staff_list.php">Staff</td>
                    </tr>


                </table>

                <div class="logout">
                    <a href="#" onclick="confirmLogout()"><img src="pics/logout.svg" alt="Logout"></a>
                </div>

            </div>



            <div id="invoice-POS">
                <div class="details">
                    <h1> IXORA MART </h1>
                    <h4> Jalan D1, 75450, Melaka</h4>
                    <h5> TEL: 06-1234567 </h5>
                </div>

                <hr class="receipt-hr">

                <br>

                <div class="invoiceDetails">
                    <?php
                    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                        $total = $_POST['totalR'];
                        $rdValue = $_POST['roundingR'];
                        $payment = $_POST['paymentR'];
                        $change = $_POST['changeR'];
                        $paymentType = $_POST['pType'];
                    }
                    ?>
                    <table>
                        <tr>
                            <?php
                            $query = "SHOW TABLE STATUS LIKE 'salesrecord'";

                            //Connect to MySQL
                            if (!($connection = mysqli_connect("localhost", "root", "", "DATABASE")))
                                die("Could not connect to database </body><html>");

                            if (!($result = mysqli_query($connection, $query))) {
                                print("<p>Could not execute query!</p>");
                                die(mysqli_error($connection) . "</body></html>");
                            }

                            $row = mysqli_fetch_assoc($result);
                            $newID = $row['Auto_increment'];
                            ?>
                            <th>Invoice No </th>
                            <td>:</td>
                            <td>
                                <?php
                                echo $newID;
                                ?>
                            </td>
                        </tr>

                        <tr>
                            <th>Date </th>
                            <td>:</td>
                            <td><?php echo $date; ?></td>
                        </tr>

                        <tr>
                            <th>Cashier </th>
                            <td>:</td>
                            <td>Manager </td>
                        </tr>
                    </table>
                </div>

                <br>

                <div class="items">
                    <table>
                        <tr>
                            <th>Description </th>
                            <th>Price</th>
                            <th>Qty</th>
                            <th style="text-align: right;">Total</th>
                        </tr>

                        <?php
                        $query = "SELECT * FROM temp_for_receipt";

                        //Connect to MySQL
                        if (!($connection = mysqli_connect("localhost", "root", "")))
                            die("Could not connect to database </body><html>");

                        //connect to tse project database
                        if (!mysqli_select_db($connection, "DATABASE"))
                            die("Could not connect to database </body><html>");

                        if (!($result = mysqli_query($connection, $query))) {
                            print("<p>Could not execute query!</p>");
                            die(mysqli_error($connection) . "</body></html>");
                        }


                        mysqli_close($connection);
                        ?>

                        <?php
                        while ($row = mysqli_fetch_row($result)) {
                            print("<tr>");

                            print("<td class=\"text-left\">");
                            echo $row['1'];
                            print("</td>");
                            print("<td class=\"text-center\">");
                            echo $row['3'];
                            print("</td>");
                            print("<td class=\"text-center\">");
                            echo $row['2'];
                            print("</td>");
                            print("<td class=\"text-right\">");
                            echo $row['4'];
                            print("</td>");

                            print("</tr>");
                        }
                        ?>


                    </table>
                </div>


                <hr style="width:100%; border:2px solid black;">

                <br>

                <div class="amount">
                    <table>
                        <tr>
                            <th>Total </th>
                            <td class="text-right">RM <?php echo $total ?> </td>
                        </tr>

                        <tr>
                            <th>Rounding </th>
                            <td class="text-right"><?php echo $rdValue ?> </td>
                        </tr>

                        <tr>
                            <th>CASH </th>
                            <td class="text-right">RM <?php $finalpayment = number_format($payment, 2, '.', '');
                                                        echo $finalpayment ?></td>
                        </tr>

                        <tr>
                            <th>Change </th>
                            <td class="text-right">RM <?php echo $change ?></td>
                        </tr>

                    </table>
                </div>

                <br>

                <p class="displayText"> Thank you! Please come again! :) </p>
                <p class="displayText"> This serves as an OFFICIAL RECEIPT </p>

            </div>
        </div>

        <div>
            <input type="hidden" id="paymentType">
            <?php
            echo "<script>";
            echo "var typeStore = document.getElementById('paymentType');";
            echo "typeStore.value = '" . $paymentType . "'";
            echo "</script>";
            ?>
            <button onclick="finishPay()" id="directButton">To Purchase Details </button>
            <script>
                function finishPay() {
                    var pType = document.getElementById('paymentType').value;
                    var total = <?php echo $total; ?>;
                    $.ajax({
                        type: 'POST',
                        url: 'updateInv.php',
                        data: {
                            pType: pType,
                            total: total
                        },
                        success: function(response) {
                            // Process the response
                            window.location.href = 'PurchaseDetails.php';
                        }
                    });
                }
            </script>
        </div>

    </div>
    <div id="confirmBox" class="confirmBox"></div>

    <div id="popup" class="popup">
        <div class="message">Are you sure?</div>
        <div class="buttons">
            <button id="confirm-button">Confirm</button>
            <button id="cancel-button">Cancel</button>
        </div>
    </div>
    <script src="confirmpopup.js"></script>




</body>

</html>