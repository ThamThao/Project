<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id'])) {
    header("Location: login.php");
    exit;
}
?>
<?php

    if (!($connection = mysqli_connect("localhost","root","","DATABASE")))
        die("Could not connect to database </body><html>");

    if(isset($_POST['temp'])){
        // Prepare a select statement
        $query = "SELECT item_description FROM inventory WHERE id = ".$_POST['temp'];
        
        if(!($result=mysqli_query($connection,$query)))
            {
                print("<p>Could not execute query!</p>");
                die(mysqli_error($connection)."</body></html>");
            }
        $row = mysqli_fetch_row($result);
        echo $row['0'];
    }

    mysqli_close($connection);
?>