<style>
    #searchform {
        background-color: #dde6ed;

        position: absolute;
        padding-left: 5px;
        padding-top: 5px;
        padding-right: 15px;
        padding-left: 5px;
        left: 620px;
        top: 200px;
        border-radius: 15px;
        box-shadow: 4px 4px gray;
        font-family: 'Roboto', sans-serif;
        font-size: 27px;
    }
</style>
<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Manager') {
	header("Location: ../login.php");
	exit;
}
?>
<table cellspacing="0" cellpadding="2" id="searchform">
    <form action="user_Inventory_Interface_searchresult.php" method="POST">
        <tr>
            <td>Search Inventory</td>
            <td><input type="text" name="search" style="font-size:16pt;" /></td>
        </tr>
        <tr>
            <td><input type="submit" value="Search" style="font-size:16pt;" /></td>
        </tr>
    </form>

</table>