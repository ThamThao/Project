<?php

// configuration
include('connectInv.php');

// new data
$category = $_POST['category'];
$brand = $_POST['brand'];
$item_description = $_POST['item_description'];
$serial_number = $_POST['serial_number'];
$price = $_POST['price'];
$stock = $_POST['stock'];
$id = $_POST['memids'];

// query
$sql = "UPDATE Inventory
        SET category=?, brand=?, item_description=?, serial_number=?, price=?, stock=?
		WHERE id=?";
$q = $db->prepare($sql);
$q->execute(array($category,$brand,$item_description,$serial_number,$price,$stock,$id));
header("location: Inventory_Interface.php");

?>
