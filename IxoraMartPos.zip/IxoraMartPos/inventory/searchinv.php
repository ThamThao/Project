<style>
	#resultTable {
		border-collapse: separate;
		background-color: #FFFFFF;
		border-spacing: 0;
		width: 86%;
		color: #666666;
		text-shadow: 0 1px 0 #FFFFFF;
		border: 1px solid #CCCCCC;
		box-shadow: 0;
		margin: 0 auto;
		font-family: arial;
		position: absolute;
		left: 240px;
		top: 85px;
	}

	table thead tr th {
		background: none repeat scroll 0 0 #EEEEEE;
		color: #222222;
		padding: 10px 14px;
		text-align: left;
		border-top: 0 none;
		font-size: 18px;
	}

	.inventory {
		background-color: #F5F595;
		font-size: 16px;
		text-align: left;
		padding: 10px 14px;
		border-top: 1px solid #DDDDDD;
		font-family: 'Roboto', sans-serif;

	}
</style>
<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Cashier' || $_SESSION['position'] === 'Sales Assistant') {
	header("Location: ../login.php");
	exit;
}
?>
<?php
include('connectInv.php');
?>

<table cellspacing="0" cellpadding="2" id="resultTable">
	<thead>
		<tr>
			<th width="13%"> Category</th>
			<th width="13%"> Brand</th>
			<th width="20%"> Item Description</th>
			<th width="15%"> Serial Number</th>
			<th width="15%"> Price</th>
			<th width="15%"> Stock</th>
			<th width="10%"> Action</th>
		</tr>
	</thead>
	<tbody>
		<?php
		$search = $_POST['search'];
		$sql = "select * from Inventory where category like '%$search%' OR brand like '%$search%' OR item_description like '%$search%' OR serial_number like '%$search%'";
		$result = $db->query($sql);
		if ($result->rowCount() > 0) {
			while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
		?>
				<tr class="inventory">
					<td><?php echo $row['category']; ?></td>
					<td><?php echo $row['brand']; ?></td>
					<td><?php echo $row['item_description']; ?></td>
					<td><?php echo $row['serial_number']; ?></td>
					<td><?php echo $row['price']; ?></td>
					<td><?php echo $row['stock']; ?></td>
					<td><a href="Inventory_Interface_edit.php?id=<?php echo $row['id']; ?>"><img src="../images/tteditbutton.png" height="15px" width="15px"></a> | <a href="#" id="<?php echo $row['id']; ?>" class="delbutton" title="Click To Delete"><img src="../images/ttdeletebutton.png" height="15px" width="15px"></a></td>
					<td>
				</tr>
			<?php
			}
			?>
		<?php
		} else {
			echo "Sorry, no records found";
		}
		?>
		<script src="../jquery-1.3.2.js"></script>
		<script type="text/javascript">
			$(function() {


				$(".delbutton").click(function() {

					//Save the link in a variable called element
					var element = $(this);

					//Find the id of the link that was clicked
					var del_id = element.attr("id");

					//Built a url to send
					var info = 'id=' + del_id;
					if (confirm("Are you sure to delete this record?")) {

						$.ajax({
							type: "GET",
							url: "deleteInv.php",
							data: info,
							success: function() {

							}
						});
						$(this).parents(".inventory").animate({
								backgroundColor: "#fbc7c7"
							}, "fast")
							.animate({
								opacity: "hide"
							}, "slow");

					}

					return false;

				});

			});
		</script>