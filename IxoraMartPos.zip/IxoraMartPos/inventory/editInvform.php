<style>
	#editform {
		background-color: #dde6ed;

		position: absolute;
		padding-left: 5px;
		padding-top: 5px;
		padding-right: 15px;
		padding-left: 5px;
		left: 550px;
		top: 200px;
		border-radius: 15px;
		box-shadow: 4px 4px gray;
		font-family: 'Roboto', sans-serif;
		font-size: 27px;
	}
</style>
<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Cashier' || $_SESSION['position'] === 'Sales Assistant') {
	header("Location: ../login.php");
	exit;
}
?>
<?php

include('connectInv.php');
$id = $_GET['id'];
$result = $db->prepare("SELECT * FROM Inventory WHERE id= :userid");
$result->bindParam(':userid', $id); //bind parameter
$result->execute();
for ($i = 0; $rows = $result->fetch(); $i++) {
?>
	<table cellspacing="0" cellpadding="2" id="editform">
		<form action="editInv.php" method="POST">
			<input type="hidden" name="memids" value="<?php echo $id; ?>" />
			<tr>
				<td>Category</td>
				<td><input type="text" name="category" value="<?php echo $rows['category']; ?>" style="font-size:16pt;" /></td>
			</tr>
			<tr>
				<td>Brand</td>
				<td><input type="text" name="brand" value="<?php echo $rows['brand']; ?>" style="font-size:16pt;" /></td>
			</tr>
			<tr>
				<td>Item Description</td>
				<td><input type="text" name="item_description" value="<?php echo $rows['item_description']; ?>" style="font-size:16pt;" /></td>
			</tr>
			<tr>
				<td>Serial Number</td>
				<td><input type="text" name="serial_number" value="<?php echo $rows['serial_number']; ?>" style="font-size:16pt;" /></td>
			</tr>
			<tr>
				<td>Price</td>
				<td><input type="text" name="price" value="<?php echo $rows['price']; ?>" style="font-size:16pt;" /></td>
			</tr>
			<tr>
				<td>Stock</td>
				<td><input type="text" name="stock" value="<?php echo $rows['stock']; ?>" style="font-size:16pt;" /></td>
			</tr>
			<tr>
				<td><input type="submit" value="Save" style="font-size:16pt;"></td>
			</tr>
		</form>
	</table>
<?php
}
?>