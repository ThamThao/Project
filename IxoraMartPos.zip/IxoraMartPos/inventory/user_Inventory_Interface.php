<!DOCTYPE html>
<html>

<head>
    <title>Ixora Mart POS Management System</title>
    <link rel="stylesheet" href="../staff_dashboard.css">
    <link rel="stylesheet" href="../confirmpopup.css">
    <script>
        function displayDateTime() {
            var currentDateTime = new Date();
            var dateTimeString = currentDateTime.toLocaleString();

            document.getElementById("dateTimeOutput").textContent = dateTimeString;
        }

        window.onload = function() {
            displayDateTime();
            setInterval(displayDateTime, 1000);
        };

        function confirmLogout() {
            showPopup().then(function(result) {
                if (result) {
                    window.location.href = "../logout.php";
                }
            });
        }
    </script>
</head>

<body>
    
    <div class="sidebar">
        <div class="navbar"></div>
        <div class="logo">
            <img src="../pics/ixoralogo.png" alt="Logo">
        </div>
        <div class="navProfile">
            <img src="../pics/staff.png" alt="Profile Picture">
        </div>
        <div id="dateTimeOutput"></div>


        <div class="sidebar"></div>
        <div class="sideProfile">
            <img src="../pics/staff.png" alt="Profile Picture">
        </div>
        <h2 class="accName">Cashier</h2>
        <h3 class="position">User</h3>

        <table class="dashboardTable">
            <tr>
                <th class="menuIcon">
                    <img src="../pics/home.svg" alt="Home">
                </th>
                <td class="sideMenu"><a href="../staff_PurchaseDetails.php">Home</td>
            </tr>
            <tr>
                <th class="menuIcon">
                    <img src="../pics/inventory.svg" alt="Inventory">
                </th>
                <td class="sideMenu"><a href="user_Inventory_Interface.php">Inventory</td>

            </tr>

            <tr>
                <th class="menuIcon">
                    <img src="../pics/parcel.svg" alt="Parcel">
                </th>
                <td class="sideMenu"><a href="../parcel/user_Parcel_Interface.php">Parcel</td>
            </tr>
        </table>

        <div class="logout">
            <a href="#" onclick="confirmLogout()"><img src="../pics/logout.svg" alt="Logout"></a>
        </div>

    </div>
    <?php include 'user_indexInv.php'; ?> <!--load inventory page-->
    <div id="confirmBox" class="confirmBox"></div>

    <div id="popup" class="popup">
        <div class="message">Are you sure?</div>
        <div class="buttons">
            <button id="confirm-button">Confirm</button>
            <button id="cancel-button">Cancel</button>
        </div>
    </div>
    <script src="../confirmpopup.js"></script>

</body>

</html>