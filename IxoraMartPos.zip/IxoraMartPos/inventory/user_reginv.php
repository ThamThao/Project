<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Manager') {
	header("Location: ../login.php");
	exit;
}
?>
<?php

include('connectInv.php');	

$category = $_POST['category'];
$brand = $_POST['brand'];
$item_description = $_POST['item_description'];
$serial_number = $_POST['serial_number'];
$price = $_POST['price'];
$stock = $_POST['stock'];

// query
$sql = "INSERT INTO Inventory (category,brand,item_description,serial_number,price,stock) VALUES (:sas,:asas,:asafs,:offff,:sasdfdf,:statttt)";
$q = $db->prepare($sql);
$q->execute(array(':sas'=>$category,':asas'=>$brand,':asafs'=>$item_description,':offff'=>$serial_number,'sasdfdf'=>$price,':statttt'=>$stock));
header("location: user_Inventory_Interface.php");


?>