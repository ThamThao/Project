<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Cashier' || $_SESSION['position'] === 'Sales Assistant') {
    header("Location: login.php");
    exit;
}
?>
<?php

    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "";
    $db_name = "DATABASE";

    $connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if(!$connection){
      die("ERROR: Connection Failed! Could not connect to the database!</body></html>");
    }

    error_reporting(1);

    // Fetch records from database 
    $query = $connection->query("SELECT * FROM staff ORDER BY staff_id ASC"); 
 
    if ($query->num_rows > 0) {
        $delimiter = ",";
        $filename = "staff_list_" . date('Y-m-d') . ".csv";
        $filepath = "C:/xampp/htdocs/TSE project/IxoraMartPOS/" . $filename;
        
        $f = fopen($filepath, 'w');
        if ($f) {
          $headers = array('ID', 'NAME', 'BIRTHDATE', 'IC', 'GENDER', 'ADDRESS', 'MARITAL_STATUS', 'EMAIL', 'CONTACT_NUMBER', 'HIRE_DATE', 'POSITION', 'BANK_NAME', 'BACK_ACC');
          fputcsv($f, $headers, $delimiter);
          
          while ($results = $query->fetch_assoc()) {
            $staff_data = array($results['staff_id'], $results['staff_name'], $results['staff_birthdate'], $results['staff_ic'], $results['staff_sex'], $results['staff_address'], $results['staff_m_status'], $results['staff_email'], $results['staff_contact'], $results['hire_date'], $results['position'], $results['bank_name'], $results['bank_acc']);
            fputcsv($f, $staff_data, $delimiter);
          }
      
          fseek($f, 0);
          fclose($f);
      
          if (file_exists($filepath)) {
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . filesize($filepath));
            readfile($filepath);
            
            // Delete the file from the server after download (optional)
            unlink($filepath);
          } else {
            echo "Failed to create the CSV file.";
          }
        } else {
          echo "Failed to open the file for writing.";
        }
      } else {
        echo "No results found for the query.";
      }
      
    exit();
?>