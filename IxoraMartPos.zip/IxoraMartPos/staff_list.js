function deleteRecord(staff_id, element) {
  showPopup().then(function (result) {
    if (result) {
      $.ajax({
        type: 'GET',
        url: 'DeleteStaff.php',
        data: { staff_id: staff_id },
        success: function () {
          $(element).closest("tr")
            .animate({
              backgroundColor: "#fbc7c7"
            }, "fast")
            .animate({
              opacity: "hide"
            }, "slow");
        }
      });
    }
  });
}