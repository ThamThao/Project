function CheckValue(event) {
    var itemNo = document.getElementById("NoTextBox").value;
    var name = document.getElementById("NameTextBox").value;
    if (itemNo == "" && name == "") {
        alert("You have to input Item No or Product Name!!");
        event.preventDefault(); // Prevent the form from being submitted
        return false;
    }
    // No need to submit the form here; it will be automatically submitted by the browser
    // when the submit button is clicked, and the input values will be sent to "search.php"
}

/*THIS SCRIPT IS TO DEFINE REAL TIME SEARCHING FOR ITEM NO*/
$(document).ready(function(){
    $('.search-box-itemno input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-itemno");
        if(inputVal.length){
            $.get("searchItemNo.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result-itemno p", function(){
        if($(this).text()=="No matches found")
        {
            $(this).parents(".search-box-itemno").find('input[type="text"]').val("");
            $(this).parent(".result-itemno").empty();
        }
        else
        {
            $(this).parents(".search-box-itemno").find('input[type="text"]').val($(this).text());
            $(this).parent(".result-itemno").empty();
            var temp = $(this).text();
            $.ajax({
                url: 'InsertPname.php',
                type: 'POST',
                data: {temp:temp},
                success: function(data) {
                    var textbox = document.getElementById("NameTextBox");
                    textbox.value = data;
                }
            });
        } 
    });
});

/*THIS SCRIPT IS TO DEFINE REAL TIME SEARCHING FOR PRODUCT NAME*/
$(document).ready(function(){
    $('.search-box-pname input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-pname");
        if(inputVal.length){
            $.get("searchPName.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result-pname p", function(){
        if($(this).text()=="No matches found")
        {
            $(this).parents(".search-box-pname").find('input[type="text"]').val("");
            $(this).parent(".result-pname").empty();
        }
        else
        {
            $(this).parents(".search-box-pname").find('input[type="text"]').val($(this).text());
            $(this).parent(".result-pname").empty();
            var temp = $(this).text();
            $.ajax({
                url: 'InsertItemNo.php',
                type: 'POST',
                data: {temp:temp},
                success: function(data) {
                    var textbox = document.getElementById("NoTextBox");
                    textbox.value = data;
                }
            });
        } 
    });
});

$(document).on("keyup input", ".search-box-pname", function(){
    var textbox = document.getElementById("NoTextBox");
    textbox.value = "";
});

$(document).on("keyup input", ".search-box-itemno", function(){
    var textbox = document.getElementById("NameTextBox");
    textbox.value = "";
});

$(document).ready(function() {
    $('#addItem').submit(function(event) {
        event.preventDefault(); // Prevent the default form submission
        
        var id = $('#NoTextBox').val();
        var name = $('#NameTextBox').val();
        
        $.ajax({
            type: 'POST',
            url: 'inv_search.php',
            data: { name: name, id: id },
            dataYype: 'json',
            success: function(response) {
                if (response) {
                    var values = JSON.parse(response);
                    var name = values.name;
                    var unitPrice = values.uprice;
                    addRow(unitPrice, name);


                  } else {
                    console.log('ERROR');
                  }
                },
                error: function(xhr, status, error) {
                  console.log('AJAX Error:', error);
                
            }
        });
    });
});

function calc() {
    var qtyInputs = document.querySelectorAll('input.qty_btn');
    var total=0;
    qtyInputs.forEach(function(qtyInput) {
      var row = qtyInput.closest('tr');
      var unitprice = parseFloat(row.querySelector('.unitPrice').textContent);
      var qty = parseFloat(qtyInput.value);
      
      var subtotal = unitprice * qty;
      total+=subtotal;
      row.querySelector('.subtotal').textContent = subtotal.toFixed(2);
    });
    //update total by add all subtotal
    document.getElementById('totalValue').textContent = total.toFixed(2);
    //get the grand total
    var grandTotal = Math.round(total * 10) / 10;
    document.getElementById('grandTotal').textContent = grandTotal.toFixed(2);
    //convert to the rounding value by substrac grandTotal with total
    var rounding = grandTotal - total;
    if(rounding===0)
    {
        document.getElementById('roundingValue').textContent = 'RM 0.00';
    }
    else if(rounding<0)
    {
        rounding = Math.abs(rounding);
        document.getElementById('roundingValue').textContent = '- RM ' + rounding.toFixed(2);
    }
    else
    {
        document.getElementById('roundingValue').textContent = '+ RM ' + rounding.toFixed(2);
    }
    var payAmount = document.getElementById('payAmount');
    payAmount.dispatchEvent(new Event("change"));
  }

function addRow(unitprice, name) {
    if(unitprice==='ERROR' || name==='ERROR')
    {
        alert("Wrong Input on Product No or Product Name!!!");
    }
    else{
        var id = document.getElementById('NoTextBox').value;
        document.getElementById('NoTextBox').value="";
        document.getElementById('NameTextBox').value="";
        // Get a reference to the table body
        var tableBody = document.querySelector('#purchaseTable tbody');

        // Create a new row
        var newRow = document.createElement('tr');

        // Create table cells and populate them with the provided data
        var idCell = document.createElement('td');
        idCell.textContent = id;
        idCell.style.textAlign = "center";
        idCell.classList.add('itemNo');

        var pnameCell = document.createElement('td');
        pnameCell.textContent = name;
        pnameCell.style.textAlign = "center";
        pnameCell.classList.add('description');

        var qtyCell = document.createElement('td');
        qtyCell.style.textAlign = "center";
        var qtyInput = document.createElement('input');
        qtyInput.type = 'number';
        qtyInput.value = 1;
        qtyInput.min = 0;
        qtyInput.classList.add('qty_btn');
        qtyCell.appendChild(qtyInput);

        qtyInput.addEventListener('change', function() {
            var quantity = parseFloat(qtyInput.value);
            if (quantity === 0) {
                if(confirm("Are you sure?"))
                {
                    newRow.remove(); // Remove the row if quantity is zero
                }
                else
                {
                    qtyInput.value=1;
                }         
            } else {
            calc(); // Proceed with the calc() function for non-zero quantity
            }
        });      

        var unitpriceCell = document.createElement('td');
        unitpriceCell.textContent = unitprice;
        unitpriceCell.style.textAlign = "center";
        unitpriceCell.classList.add('unitPrice');

        var subtotalCell = document.createElement('td');
        subtotalCell.textContent = '0.00';
        subtotalCell.style.textAlign = "center";
        subtotalCell.classList.add('subtotal')

        // Append the cells to the row
        newRow.appendChild(idCell);
        newRow.appendChild(pnameCell);
        newRow.appendChild(qtyCell);
        newRow.appendChild(unitpriceCell);
        newRow.appendChild(subtotalCell);

        // Append the row to the table body
        tableBody.appendChild(newRow);
        calc();
    }
    
    
}

function paymentUpdate(type)
{
    document.getElementById('paymentType').textContent = type;
}

function checkPayment()
{
    var payment = parseFloat(document.getElementById('payAmount').value);
    var total = parseFloat(document.getElementById('totalValue').textContent);
    var paymentType = document.getElementById('paymentType').textContent;
    if (paymentType === "")
    {
        alert ("Please choose a payment type!!!");
    }
    else if (total != 0)
    {
        if (payment < total || isNaN(payment))
        {
            alert ("Payment amount is insufficient!!!");
        }
        else
        {
            tableTransfer();
        }
    }
    else{
        alert("You haven't enter any product!!!");
    }
}

function tableTransfer() {
    var tableRows = document.querySelectorAll('#purchaseTable tbody tr');
    var check = "";
    // Iterate over each row and collect the data
    tableRows.forEach(function(row) {
        var id = row.querySelector('.itemNo').textContent;
        var name = row.querySelector('.description').textContent;
        var qty = row.querySelector('.qty_btn').value;
        var unitPrice = row.querySelector('.unitPrice').textContent;
        var subtotal = row.querySelector('.subtotal').textContent;

        $.ajax({
            type: 'POST',
            url: 'insertTempDBS.php',
            data: {  id: id,name: name,qty: qty, unitPrice: unitPrice, subtotal: subtotal },
            success: function(response) {
                // Process the response
                if(response === "OK")
                    check = "TRUE";
            }
        });
    });

    var total = document.getElementById('totalValue').textContent;
    var rdValue = document.getElementById('roundingValue').textContent;
    var payment = document.getElementById('payAmount').value;
    var change = document.getElementById('change').textContent;
    var paymentType = document.getElementById('paymentType').textContent;

    document.getElementById('totalR').value = total;
    document.getElementById('roundingR').value = rdValue;
    document.getElementById('paymentR').value = payment;
    document.getElementById('changeR').value = change;
    document.getElementById('pType').value = paymentType;

    var form = document.getElementById('transferForm');
    form.submit();
}

