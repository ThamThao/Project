<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id'])) {
    header("Location: login.php");
    exit;
}
?>
<?php

if (!($connection = mysqli_connect("localhost", "root", "", "DATABASE")))
    die("Could not connect to database </body><html>");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    // Process the data here
    $query = "SELECT * FROM inventory WHERE id = " . $id;
    if (!($result = mysqli_query($connection, $query))) {
        print("<p>Could not execute query!</p>");
        die(mysqli_error($connection) . "</body></html>");
    }

    if (mysqli_num_rows($result) > 0) {
        // Fetch the row data
        $row = mysqli_fetch_row($result);
        $ides = $row[3];
        $uprice = $row[5];

        $response = array(
            'name' => $ides,
            'uprice' => $uprice
        );
        echo json_encode($response);
    } else {
        echo "ERROR";
    }

    mysqli_close($connection);
}

?>