<!DOCTYPE html>
<html>

<head>
    <title>Login Page</title>
    <link rel="stylesheet" href="login.css">
    <style>
        body {
            background-image: url('images/ixoralogin.jpg');
            background-size: cover;
            background-repeat: no-repeat;
        }
    </style>

</head>

<body>
    <div class="login-form">
        <form method="POST" action="login.php">
            <div class="container">
                <span>Ixora Mart</span><br>
                <span>Login</span>
            </div>
            <label for="staff_id">Staff ID:</label>
            <input type="number" name="staff_id" placeholder="Please Enter Your ID..." required>

            <label for="password">Password:</label>
            <input type="password" name="password" placeholder="Please Enter Password..." required>

            <?php
            session_start();
            require 'db.php';
            $conn = mysqli_connect("localhost", "root", "", "DATABASE");

            if (!$conn) {
                die("Could not connect to server!</body></html>");
            }

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $uid = "";
                $uid = $_POST['staff_id'];
                $password = $_POST['password'];
                $query = "SELECT * FROM staff WHERE staff_id = '" . $uid . "'";

                if (!($result = mysqli_query($conn, $query))) {
                    print "Cannot run the query";
                }

                // Check if a matching user is found
                if ($result->num_rows === 1) {
                    $user = $result->fetch_assoc();

                    if ($password == $user['password']) {
                        $_SESSION['staff_id'] = $user['staff_id'];
                        $_SESSION['position'] = $user['position'];
                        $_SESSION['authenticated'] = true;

                        if ($user['position'] === 'Cashier') {
                            header("Location: staff_PurchaseDetails.php");
                        } else {
                            header("Location: PurchaseDetails.php");
                        }
                        exit;
                    } else {
                        // Invalid password
                        echo "<div class='alert'>Invalid ID or PASSWORD</div>";
                    }
                } else {
                    // Invalid username
                    echo "<div class='alert'>Invalid ID or PASSWORD</div>";
                }
            }


            mysqli_close($conn);

            ?>

            <?php if (!empty($alert)) { ?>

                <div class="alert">
                    <?php echo $alert; ?>
                </div>
            <?php } ?>

            <div class="button-container">
                <button type="submit">Login</button>

            </div>
        </form>
    </div>
    <script>
        // Get the alert element
        var alertBox = document.querySelector('.alert');

        // Check if the alert element exists
        if (alertBox) {
            // Hide the alert after 3 seconds
            setTimeout(function() {
                alertBox.style.display = 'none';
            }, 3000);
        }
    </script>
</body>

</html>