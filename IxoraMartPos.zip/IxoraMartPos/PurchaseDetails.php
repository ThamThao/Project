<!DOCTYPE html>
<html>

<head>
    <title>Purchase Details</title>
    <link rel="stylesheet" href="PurchaseDetails.css">
    <link rel="stylesheet" href="admin_dashboard_design.css">
    <link rel="stylesheet" href="confirmpopup.css">

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="PurchaseDetails.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#payButton').click(function() {
                window.open('payment.php', 'Pop-out Page', 'width=700, height=450');
            });
        });

        function displayDateTime() {
            var currentDateTime = new Date();
            var dateTimeString = currentDateTime.toLocaleString();

            document.getElementById("dateTimeOutput").textContent = dateTimeString;
        }

        window.onload = function() {
            displayDateTime();
            setInterval(displayDateTime, 1000);
        };

        function confirmLogout() {
            showPopup().then(function(result) {
                if (result) {
                    window.location.href = "logout.php";
                }
            });
        }
    </script>

</head>

<body>
    <?php
    session_start();

    // Check if user is logged in and the role
    if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Cashier' || $_SESSION['position'] === 'Sales Assistant') {
        header("Location: login.php");
        exit;
    }
    ?>
    <div class="container">

        <div class="sidebar">
            <div class="navbar"></div>
            <div class="logo">
                <img src="pics/ixoralogo.png" alt="Logo">
            </div>

            <div class="navProfile">
                <img src="pics/manager.png" alt="Profile Picture">
            </div>
            <div id="dateTimeOutput"></div>


            <div class="sidebar"></div>
            <div class="sideProfile">
                <img src="pics/manager.png" alt="Profile Picture">
            </div>
            <h2 class="accName">Manager</h2>
            <h3 class="position">Admin</h3>

            <table class="dashboardTable">
                <tr>
                    <th class="menuIcon">
                        <img src="pics/home.svg" alt="Home">
                    </th>
                    <td class="sideMenu"><a href="PurchaseDetails.php">Home</td>
                </tr>

                <tr>
                    <th class="menuIcon">
                        <img src="pics/sales.svg" alt="Sales">
                    </th>
                    <td class="sideMenu"><a href="SalesRecord.php">Sales</td>
                </tr>

                <tr>
                    <th class="menuIcon">
                        <img src="pics/inventory.svg" alt="Inventory">
                    </th>
                    <td class="sideMenu"><a href="inventory/Inventory_Interface.php">Inventory</td>

                </tr>

                <tr>
                    <th class="menuIcon">
                        <img src="pics/parcel.svg" alt="Parcel">
                    </th>
                    <td class="sideMenu"><a href="parcel/Parcel_Interface.php">Parcel</td>
                </tr>

                <tr>
                    <th class="menuIcon">
                        <img src="pics/staff.svg" alt="Staff">
                    </th>
                    <td class="sideMenu"><a href="staff_list.php">Staff</td>
                </tr>
            </table>

            <div class="logout">
                <a href="#" onclick="confirmLogout()"><img src="pics/logout.svg" alt="Logout"></a>
            </div>

        </div>

        <div class="purchaseDetails">
            <?php
            if (!($connection = mysqli_connect("localhost", "root", "", "DATABASE")))
                die("Could not connect to database </body><html>");

            $dltQuery = "DELETE FROM temp_for_receipt";
            if (!($result = mysqli_query($connection, $dltQuery))) {
                print("<p>Could not execute query!</p>");
                die(mysqli_error($connection) . "</body></html>");
            }

            if (mysqli_affected_rows($connection) < 0) {
                //output result
                echo "<script>";
                echo "alert('Unexpected error occured. Please Try Again')";
                echo "window.location.href = 'PurchaseDetails.php'";
                echo "</script>";
            }
            ?>
            <div class="header">
                <h2>PURCHASE DETAILS</h2>

                <div class="details">
                    <table>
                        <tr>
                            <th class="text-left">Cashier</th>
                            <td>:</td>
                            <td>Manager </td>

                        <tr>
                            <th class="text-left">Date</th>
                            <td>:</td>

                            <td id="date">
                                <script>
                                    var currentDate = new Date();
                                    var options = {
                                        day: '2-digit',
                                        month: '2-digit',
                                        year: 'numeric'
                                    };
                                    document.getElementById("date").textContent = currentDate.toLocaleDateString(undefined, options);
                                </script>
                            </td>
                        </tr>
                        <tr>
                            <th class="text-left">Time</th>
                            <td>:</td>

                            <td id="time">
                                <script>
                                    function getTime() {
                                        var currentTime = new Date();
                                        var hours = currentTime.getHours();
                                        var minutes = currentTime.getMinutes();
                                        var seconds = currentTime.getSeconds();

                                        var formattedTime = hours.toString().padStart(2, '0') + ':' + minutes.toString().padStart(2, '0') + ':' + seconds.toString().padStart(2, '0');

                                        document.getElementById("time").textContent = formattedTime;
                                    }
                                    setInterval(function() {
                                        getTime()
                                    }, 1000);
                                </script>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <div id="item_table">
                <br>
                <table style="width:100%" id="purchaseTable">
                    <thead>
                        <tr>
                            <th style="width:10%">Item No</th>
                            <th style="width:30%">Description</th>
                            <th>Qty</th>
                            <th>Unit Price</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>

                    <tbody>
                    </tbody>
                </table>
            </div>

            <br>

            <form action="inv_search.php" id="addItem" method="post">
                <div class="search">
                    <table>
                        <tr>
                            <th valign="middle">
                                Product No:
                            </th>

                            <td valign="top">
                                <div class="search-box-itemno">
                                    <input type="text" autocomplete="off" placeholder="Search Item No..." id="NoTextBox" name="NoTextBox" />
                                    <div class="result-itemno"></div>
                                </div>
                            </td>

                            <th valign="middle">
                                Product Name:
                            </th>

                            <td valign="top">
                                <div class="search-box-pname">
                                    <input type="text" autocomplete="off" placeholder="Search Product Name..." id="NameTextBox" name="NameTextBox" />
                                    <div class="result-pname"></div>
                                </div>
                            </td>


                            <td valign="middle">
                                <input class="button" type="reset" value="Clear">
                                <input class="button" type="submit" value="Add" onclick="CheckValue(event)">
                            </td>

                        </tr>
                    </table>
                </div>
            </form>

        </div>
    </div>
    <br>
    <br>

    <div class="flexibleBox">
        <div class="left-div">
            <div>
                <button class="paymentbutton" onclick="paymentUpdate('Cash')">
                    <img src="images/cash.png" width="100px" height="60px" alt="Cash" style="padding-top:20px; padding-left:30px; padding-right:30px;">
                    <div class="textCenter">Cash</div>
                </button>
            </div>

            <br>

            <div>
                <button class="paymentbutton" onclick="paymentUpdate('Credit/ Debit')">
                    <img src="images/credit_debit.png" width="90px" height="80px" alt="Credit/Debit" style="padding-top:10px; padding-left:35px; padding-right:35px;">
                    <div class="textCenter">Credit/ Debit</div>
                </button>
            </div>

            <br>

            <div>
                <button class="paymentbutton" onclick="paymentUpdate('QR Pay')">
                    <img src="images/qrpay.png" width="120px" height="90px" alt="QR Pay" style="padding-top:5px; padding-left:20px; padding-right:20px;">
                    <div class="textCenter">QR Pay</div>
                </button>
            </div>
        </div>

        <div class="right-div">
            <div class="paymentTable">
                <table>
                    <tr>
                        <th>Total </th>
                        <td>: </td>
                        <td>RM <span id="totalValue">0.00<span></td>
                    </tr>

                    <tr>
                        <th>Rounding </th>
                        <td>: </td>
                        <td><span id="roundingValue">RM 0.00</span></td>
                    </tr>

                    <tr>
                        <th>Grand Total </th>
                        <td>: </td>
                        <td>RM <span id="grandTotal">0.00<span></td>
                    </tr>

                    <tr>
                        <th>Payment Type </th>
                        <td>:</td>
                        <td id="paymentType"></td>
                        <script>
                            var paymentIpt = document.getElementById('paymentType');
                            paymentIpt.addEventListener('change', function() {
                                if (paymentIpt.value === '') {
                                    paymentIpt.value = 0;
                                }
                            });
                        </script>
                    </tr>

                    <tr>
                        <th>Pay Amount </th>
                        <td>: </td>
                        <td><input type="number" name="amount" size="20" maxlength="20" min="0" value="0" id="payAmount"></td>
                        <script>
                            const payAmountIPT = document.getElementById('payAmount');

                            payAmountIPT.addEventListener('change', function() {
                                var grandTotal = parseFloat(document.getElementById('grandTotal').textContent);
                                var payAmount = parseFloat(payAmountIPT.value);
                                var change = payAmount - grandTotal;
                                if (change >= 0) {
                                    document.getElementById('change').textContent = change.toFixed(2);
                                } else {
                                    document.getElementById('change').textContent = '0.00';
                                }
                            });
                        </script>
                    </tr>

                    <tr>
                        <th>Change </th>
                        <td>: </td>
                        <td>RM <span id="change">0.00</span></td>
                    </tr>
                </table>

            </div>

            <div class="print">
                <button id="printButton" onclick="checkPayment()">Print Receipt</button>
            </div>
            <form action="receipt.php" method="post" id="transferForm">
                <input type="hidden" id="totalR" name="totalR">
                <input type="hidden" id="roundingR" name="roundingR">
                <input type="hidden" id="paymentR" name="paymentR">
                <input type="hidden" id="changeR" name="changeR">
                <input type="hidden" id="pType" name="pType">
            </form>

        </div>

    </div>

    </div>
    <div id="confirmBox" class="confirmBox"></div>

    <div id="popup" class="popup">
        <div class="message">Are you sure?</div>
        <div class="buttons">
            <button id="confirm-button">Confirm</button>
            <button id="cancel-button">Cancel</button>
        </div>
    </div>
    <script src="confirmpopup.js"></script>

</body>

</html>