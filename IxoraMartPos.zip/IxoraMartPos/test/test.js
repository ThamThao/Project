// Get references to the pop-up and buttons
popupBox = document.getElementById("confirmBox");
popup = document.getElementById("popup");
confirmButton = document.getElementById("confirm-button");
cancelButton = document.getElementById("cancel-button");

// Function to show the confirmation pop-up
function showPopup() {
  popupBox.style.display = "block";
  popup.style.display = "block";
  return new Promise(function(resolve) {
    confirmButton.addEventListener("click", function() {
      hidePopup();
      resolve(true);
    });

    cancelButton.addEventListener("click", function() {
      hidePopup();
      resolve(false);
    });
  });
}

// Function to hide the confirmation pop-up
function hidePopup() {
  popupBox.style.display = "none";
  popup.style.display = "none";
}

// Event listeners for confirm and cancel buttons
