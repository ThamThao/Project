function deleteRecord(inv_no, element) {
  showPopup().then(function (result) {
    if (result) {
      $.ajax({
        type: 'POST',
        url: 'DeleteSalesRecord.php',
        data: { inv_no: inv_no },
        success: function () {
          $(element).parents(".sales")
            .animate({
              backgroundColor: "#fbc7c7"
            }, "fast")
            .animate({
              opacity: "hide"
            }, "slow");
        }
      });
    }
  });

}