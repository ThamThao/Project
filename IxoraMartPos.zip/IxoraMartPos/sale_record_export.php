<?php
    session_start();

    // Check if user is logged in and the role
    if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Cashier' || $_SESSION['position'] === 'Sales Assistant') {
        header("Location: login.php");
        exit;
    }
    ?>
<?php

    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "";
    $db_name = "DATABASE";

    $connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if(!$connection){
      die("ERROR: Connection Failed! Could not connect to the database!</body></html>");
    }

    error_reporting(1);

    // Fetch records from database 
    $query = $connection->query("SELECT * FROM `salesrecord` WHERE Date = CURDATE()"); 
 
    if($query->num_rows > 0){ 
        $delimiter = ","; 
        $filename = "daily_sales_report_" . date('Y-m-d') . ".csv"; 
                                    
        // Set the file path to save the CSV
        $filepath = "C:/xampp/htdocs/TSE project/IxoraMartPos/" . $filename;

        $f = fopen($filepath, 'w'); 
                                    
    // Set column headers 
        $headers = array('Inv No', 'Payment Type', 'Date', 'Total(RM)'); 
        fputcsv($f, $headers, $delimiter); 
                                    
        // Output each row of the data, format line as csv and write to file pointer 
        while($results = $query->fetch_assoc()){ 
        $salesrecord = array($results['Inv_No'], $results['Payment Type'], $results['Date'], $results['Total']); 
        fputcsv($f, $salesrecord, $delimiter); 
        } 

        fseek($f, 0);
        
        // Set headers to download file
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($filepath));

        // Read and output the file content
        readfile($filepath);

        // Delete the file from the server after download (optional)
        unlink($filepath);
    }
    exit();
?>