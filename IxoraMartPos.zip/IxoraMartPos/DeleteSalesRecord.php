<?php
session_start();

// Check if user is logged in and the role
if (!isset($_SESSION['staff_id']) || $_SESSION['position'] === 'Cashier' || $_SESSION['position'] === 'Sales Assistant') {
    header("Location: login.php");
    exit;
}
?>
<?php

if (!($connection = mysqli_connect("localhost", "root", "", "DATABASE")))
    die("Could not connect to database </body><html>");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['inv_no'];

    // Process the data here
    $query = "DELETE FROM salesrecord WHERE inv_no = " . $id;
    if (!($result = mysqli_query($connection, $query))) {
        print("<p>Could not execute query!</p>");
        die(mysqli_error($connection) . "</body></html>");
    }

    mysqli_close($connection);
}
?>