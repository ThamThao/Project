<!DOCTYPE html>
<html>

<head>
</head>

<body>
    <?php
    $host = 'localhost';
    $dbname = 'DATABASE';
    $username = 'root';
    $password = '';

    $conn = mysqli_connect($host, $username, $password, $dbname)
    ?>

</body>

</html>