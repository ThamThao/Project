function displayDateTime(){
    var currentDateTime = new Date();
    var dateTimeString = currentDateTime.toLocaleString();
    
    document.getElementById("dateTimeOutput").textContent = dateTimeString;
}

window.onload  = function(){
    displayDateTime();
    setInterval(displayDateTime, 1000);
};