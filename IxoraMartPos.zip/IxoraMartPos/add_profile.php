<?php
include_once('admin_dashboard.php');

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "DATABASE";

$connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$connection) {
    die("ERROR: Connection Failed! Could not connect to the database!</body></html>");
}

error_reporting(1);

if (!mysqli_select_db($connection, $db_name)) {
    die("Could not open Company database.</body></html>");
}

if (isset($_POST["btnSubmit"])) {
    extract($_POST);

    $query = "INSERT INTO staff (staff_id, staff_name, staff_birthdate, staff_ic, staff_sex, staff_address, staff_m_status, staff_email, staff_contact, hire_date, position, bank_name, bank_acc, password) VALUES ('', '$name', '$birthdate', '$ic', '$gender', '$address', '$m_status', '$email', '$contact', '$hire_date', '$position', '$bankname', '$bankacc', '$password')";

    if (mysqli_query($connection, $query)) {
        echo "Record inserted successfully.";
    } else {
        echo "ERROR: Could not execute query. " . mysqli_error($connection);
    }
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="confirmpopup.css">
    <title>New Staff</title>
    <style>
        body {
            height: 1000px;
        }


        .label-bold {
            color: #000000;
            font-family: 'Open Sans', sans-serif;
            font-weight: bolder;
            font-size: 16px;
            margin: 20px;

        }

        .label-bold th,
        td {
            border-bottom: 0;
        }

        .textField {
            height: 30px;
            background: #FFFFFF;
            border: 1px solid #C5C4C4;
            border-radius: 8px;
            font-family: 'Roboto', sans-serif;
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            color: black;
            padding: 5px;
            margin: 20px;

        }

        .yellowBtn {
            background-color: #F9EAE1;
            width: 80px;
            height: 30px;
            box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.25);
            border-radius: 8px;
            color: black;
            font-family: 'Open Sans', sans-serif;
            font-style: normal;
            font-weight: bolder;
            font-size: 12px;
            text-decoration: none;
            border: #F9EAE1;
        }

        a {
            text-decoration: none;

        }

        a:hover,
        a:visited {
            color: #000000;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <div class="container">
        <form action="" method="post" id="myForm">
            <h2 style="position: absolute; top: 96px; left: 305px; font-family: 'Open Sans', sans-serif; font-weight: bolder; font-size: 22px;">New Staff</h2>
            <table style="position: absolute; left: 500px; top: 125px;">
                <tr>
                    <td class="label-bold">Name</td>
                    <td><input class="textField" type="text" name="name" pattern="[a-zA-Z_][a-zA-Z_ ]*[a-zA-Z_]$" title="The name of the staff can only contain string!" required></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td class="label-bold">Date of Birth</td>
                    <td><input class="textField" type="date" name="birthdate" required></td>
                    <td></td>
                    <td class="label-bold">No. IC</td>
                    <td><input class="textField" type="text" name="ic" pattern="\d{6}-\d{2}-\d{4}$" title="You have entered an invalid IC number!" required></td>
                </tr>
                <tr>
                    <td class="label-bold">Gender</td>
                    <td>
                        <select name="gender" class="textField">
                            <option value="M"> Male</option>
                            <option value="F"> Female</option>
                        </select>
                    </td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td class="label-bold">Address</td>
                    <td colspan=4><input class="textField" type="text" name="address" size="50" required></td>
                </tr>

                <tr>
                    <td class="label-bold">Marital Status</td>
                    <td>
                        <select name="m_status" class="textField">
                            <option value="Single">Single</option>
                            <option value="Married">Married</option>
                        </select>
                    </td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>

                <tr>
                    <td class="label-bold">Email</td>
                    <td><input class="textField" type="email" name="email" title="You have entered an invalid email address!" required></td>
                    <td></td>
                    <td class="label-bold">Contact</td>
                    <td><input class="textField" type="text" name="contact" pattern="\d*$" title="You have entered an invalid contact number!" required></td>
                </tr>

                <tr>
                    <td class="label-bold">Hire Date</td>
                    <td><input class="textField" type="date" name="hire_date" required></td>
                    <td></td>
                    <td class="label-bold">Position</td>
                    <td>
                        <select name="position" class="textField">
                            <option selected value="Sales Assistant">Sales Assistant</option>
                            <option value="Cashier">Cashier</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td class="label-bold">Bank Name</td>
                    <td><input class="textField" type="text" name="bankname" pattern="[a-zA-Z_][a-zA-Z_ ]*[a-zA-Z_]$" title="The name of the bank can only contain string!" required></td>
                    <td></td>
                    <td class="label-bold">Account No.</td>
                    <td><input class="textField" type="text" name="bankacc" pattern="\d*$" title="Account No. can only contain number!" required></td>
                </tr>

                <tr>
                    <td class="label-bold">Password</td>
                    <td><input class="textField" type="text" name="password" required></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>

                <tr>
                    <td></td>
                    <td><input class="yellowBtn" type="submit" name="btnSubmit" value="Save"></td>
                    <td><a href="staff_list.php"><input class="yellowBtn" type="button" name="btnCancel" value="Cancel"></a></td>
                    <td></td>

                </tr>
            </table>
        </form>
    </div>
    <div id="confirmBox" class="confirmBox"></div>

    <div id="popup" class="popup">
        <div class="message">Are you sure?</div>
        <div class="buttons">
            <button id="confirm-button">Confirm</button>
            <button id="cancel-button">Cancel</button>
        </div>
    </div>
    <script src="confirmpopup.js"></script>
</body>

</html>