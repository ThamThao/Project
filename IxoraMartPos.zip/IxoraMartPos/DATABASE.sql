SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
--
-- Table structure for table `ParcelRecord`
--

CREATE TABLE IF NOT EXISTS `ParcelRecord` (
`id` int(11) NOT NULL,
  `date_in` varchar(100) NOT NULL,
  `date_out` varchar(100) NOT NULL,
  `parcel_ID` varchar(1000) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `block_no` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ParcelRecord`
--

INSERT INTO `ParcelRecord` (`id`, `date_in`, `date_out`, `parcel_ID`, `customer_name`, `block_no`, `status`) VALUES
(1, '10/05/2023', '11/05/2023', '123456789', 'tto', 'c0901', 'Completed'),
(2, '10/05/2023', '12/05/2023', '123454489', 'tt', 'c0902', 'Completed'),
(3, '10/05/2023', '11/05/2023', '126346789', 'ttao', 'c0903', 'Pending');

--
-- Indexes for table `ParcelRecord`
--
ALTER TABLE `ParcelRecord`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for table `ParcelRecord`
--
ALTER TABLE `ParcelRecord`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;

--
-- Table structure for table `inventory`
--

CREATE TABLE IF NOT EXISTS `Inventory` (
`id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `item_description` varchar(1000) NOT NULL,
  `serial_number` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `stock` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Inventory`
--

INSERT INTO `Inventory` (`id`, `category`, `brand`, `item_description`, `serial_number`,`price`, `stock`) VALUES
(1, 'stationary', 'Stabilo', 'Stabilo 2B Pencil', '123456', '1.50', '10'),
(2, 'food', 'Gardenia', 'Gardenia Strawberry Bread', 'ae12345', '2.00', '20'),
(3, 'drink', 'CocaCola', 'CocaCola 1.5L', 'cc12376', '2.80', '30');

--
-- Indexes for table `ParcelRecord`
--
ALTER TABLE `Inventory`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for table `ParcelRecord`
--
ALTER TABLE `Inventory`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(5) NOT NULL,
  `staff_name` varchar(30) NOT NULL,
  `staff_birthdate` date NOT NULL,
  `staff_ic` varchar(15) NOT NULL,
  `staff_sex` char(1) NOT NULL,
  `staff_address` varchar(50) NOT NULL,
  `staff_m_status` varchar(7) NOT NULL,
  `staff_email` varchar(20) NOT NULL,
  `staff_contact` varchar(12) NOT NULL,
  `hire_date` date NOT NULL,
  `position` varchar(20) NOT NULL,
  `bank_name` varchar(20) NOT NULL,
  `bank_acc` varchar(20) NOT NULL,
  `password` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_name`, `staff_birthdate`, `staff_ic`, `staff_sex`, `staff_address`, `staff_m_status`, `staff_email`, `staff_contact`, `hire_date`, `position`, `bank_name`, `bank_acc`, `password`) VALUES
(10001, 'Lee Li', '1990-01-01', '900101-01-0001', 'M', '', 'Single', '', '012-3456789', '2023-05-26', 'Cashier', 'Lee Li', '1002003004', 'lee1234'),
(10002, 'Tan', '1988-08-08', '880808-04-0881', 'M', '', 'Married', '', '012-1212345', '2018-08-26', 'Manager', 'Tan Seng', '1002004005', 'tan0808');

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10003;
COMMIT;

--
-- Table structure for table `salesrecord`
--

CREATE TABLE `salesrecord` (
  `Inv_No` int(5) NOT NULL,
  `Payment Type` varchar(100) NOT NULL,
  `Date` date NOT NULL,
  `Total` float(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salesrecord`
--

INSERT INTO `salesrecord` (`Inv_No`, `Payment Type`, `Date`, `Total`) VALUES
(10001, 'TNGO', '2023-03-12', 33.00),
(10002, 'Cash', '2023-03-12', 200.00),
(10003, 'Bank Transfer', '2023-03-05', 220.00),
(10004, 'Bank Transfer', '2023-03-12', 55.60);

--
-- Table structure for table `temp_for_receipt`
--

CREATE TABLE `temp_for_receipt` (
  `item_no` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(4,2) NOT NULL,
  `subtotal` decimal(4,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for table `salesrecord`
--
ALTER TABLE `salesrecord`
  ADD PRIMARY KEY (`Inv_No`);

--
-- AUTO_INCREMENT for table `salesrecord`
--
ALTER TABLE `salesrecord`
  MODIFY `Inv_No` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10009;
